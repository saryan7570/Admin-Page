package com.cg.plp.controller;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.plp.dao.CustomerDao;
import com.cg.plp.dao.MerchantDao;
import com.cg.plp.dao.ProductDao;
import com.cg.plp.entity.Customer;
import com.cg.plp.entity.Merchant;
import com.cg.plp.entity.Product;

@CrossOrigin(origins="http://localhost:4200")
@RestController
public class Controller {
	
	Customer customer;
	
	@Autowired
	CustomerDao customerDao;

	@Autowired
	ProductDao productDao;

	@Autowired
	MerchantDao merchantDao;

	@GetMapping("/getCustomer")
	public List<Customer> getCustomer() {
		customer = new Customer(100, "Nitin", 123);
		customerDao.save(customer);
		customer = new Customer(101, "Ankit", 456);
		customerDao.save(customer);
		return customerDao.findAll();
	}

	@GetMapping("/getProduct")
	public List<Product> getProduct() {
		return productDao.findAll();
	}

	@GetMapping("/getMerchant")
	public List<Merchant> getMerchant() {
		return merchantDao.findAll();
	}

}